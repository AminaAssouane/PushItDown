/* Classe qui impl�mente quelque r�gles du jeu */
public abstract class Jeu {
	
	// Tableau qui liste les niveaux disponibles
	public Niveau niveaux[];
	
	// M�thode qui determine si le d�placement voulu est autoris�
	public static boolean deplacementOK(Plateau P, Case caseNow, int coordXD, int coordYD){
		
		// si on sort des bornes
		if ((coordXD < 0) || (coordYD < 0)  
				|| (coordXD > P.getHauteur()) || (coordYD > P.getLargeur())){
			return false;
		}
		else {
			if (P.getCase(coordXD,coordYD).getAxeZ() > caseNow.getAxeZ()){
				return false;
			}
			else {
				return true;
			}
		}
	}
	
	public boolean gagne(){
		return true;
	}
}
