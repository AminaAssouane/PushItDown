
public class Niveau {
	public Plateau P;	
}
