
public enum Niveaux {
	Niveau1,
	Niveau2,
	Niveau3,
	Niveau4,
	Niveau5;
}
