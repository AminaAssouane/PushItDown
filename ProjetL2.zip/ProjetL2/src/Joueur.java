
public class Joueur {
	int score;
}
