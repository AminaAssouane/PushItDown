
public class Case {
	
	private int axeX;
	private int axeY;
	private int axeZ;
	private boolean boule;
	private boolean sortie;
	
	
	// Getters //
	public int getAxeX(){
		return this.axeX;
	}
	
	public int getAxeY(){
		return this.axeY;
	}
	
	public int getAxeZ(){
		return this.axeZ;
	}

}
