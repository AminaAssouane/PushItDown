
public class autoresolve {
	int attempts;
	autoresolve alternative_strategy;
	char hint[];
	
}
