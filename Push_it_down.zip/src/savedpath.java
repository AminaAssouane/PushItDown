
public class savedpath {
	int moves;
	
	void savepath(String path) {
	}
	void loadpath(String path) {
	}

}
