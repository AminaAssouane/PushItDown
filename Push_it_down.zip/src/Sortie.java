
public class Sortie {
	int x,y,z;
	Bille b;
	Sortie(Bille b){
		this.b=b;
	}
}
