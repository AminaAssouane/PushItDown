import java.util.ArrayList;

public class Plateau {
	private Cellule [][][] plateau;
	
	public Plateau (int x, int y, int z) {
		this.plateau = new Cellule [x][y][z];
	}
	
	public boolean addCellule(int x, int y, int z, Cellule c) {
		if (x < plateau.length && y < plateau[x].length && z < plateau[x][y].length && plateau[x][y][z]== null) {
			plateau[x][y][z]= new Cellule (x,y,z,1,null);
			return true;
		}
		return false;
	}
	
	public ArrayList<Deplacement> test_possible(Joueur j){
		ArrayList <Deplacement> d= new ArrayList <Deplacement>();
		if (test_case(j.getX()+1, j.getY(), test_hauteur(j.getX(), j.getY(), j.getZ()))) {
			d.add(new Deplacement(j, j.getX()+1, j.getY(), test_hauteur(j.getX(), j.getY(), j.getZ())));
		}
		
		
		if (test_case(j.getX()-1, j.getY(), test_hauteur(j.getX(), j.getY(), j.getZ()))) {
			d.add(new Deplacement(j, j.getX()-1, j.getY(), test_hauteur(j.getX(), j.getY(), j.getZ())));
		}
		
		if (test_case(j.getX(), j.getY()+1, test_hauteur(j.getX(), j.getY(), j.getZ()))) {
			d.add(new Deplacement(j, j.getX(), j.getY()-1, test_hauteur(j.getX(), j.getY(), j.getZ())));
		}
		
		if (test_case(j.getX()+1, j.getY()-1, test_hauteur(j.getX(), j.getY(), j.getZ()))) {
			d.add(new Deplacement(j, j.getX(), j.getY()+1, test_hauteur(j.getX(), j.getY(), j.getZ())));
		}
		
		return d;
	}	
	
	public int test_hauteur(int x, int y, int z) {
		while (this.plateau[x][y][z]== null) {
			z--;
		}
		if (this.plateau[x][y][z].j == null) {
			return z;
		}
		else {
			return -1;
		}
	}
	
	public void deplacement(Entite j, int x, int y, int z) {
		if (test_case(x,y,z)) plateau[x][y][z].j = j;
	}
	
	public boolean test_case(int x, int y, int z){
		if (x < plateau.length && y < plateau[x].length && z < plateau[x][y].length && plateau[x][y][z].j == null) {
			return true;
		}
		return false;
	}
	
	private class Cellule {
		private int x;
		private int y;
		private int z;
		private int color;
		Entite j;
		
		public Cellule (int x, int y, int z, int color, Entite j) {
			this.x = x;
			this.y = y;
			this.z = z;
			this.color = color;
			this.j = j;
		}
		
		public int getColore() {
			return this.color;
		}
	}
}