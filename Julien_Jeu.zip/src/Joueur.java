import java.util.ArrayList;

public class Joueur implements Entite {
	private String nom;
	private ArrayList <Deplacement> deplacements;
	private int x;
	private int y;
	private int z;
	private int score;
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getZ() {
		return z;
	}
	public void setZ(int z) {
		this.z = z;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public ArrayList <Deplacement> getDeplacements() {
		return deplacements;
	}
	public void setDeplacements(ArrayList <Deplacement> deplacements) {
		this.deplacements = deplacements;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	
}
