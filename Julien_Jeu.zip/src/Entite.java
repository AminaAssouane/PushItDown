
public interface Entite {

}
