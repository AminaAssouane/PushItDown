import java.util.ArrayList;

public class Jeu {
	
	private int nbRetour;
	// Si nombre de retour est n�gatif, le nombre de retour en arri�re possible est Infini
	private ArrayList <Joueur> joueurs;
	// Possibilit� d'avoir un jeu multi-joueur
	private Joueur gagnant;
	private int actuel;
	
	private Plateau plateau;
	
	public Jeu (int nbRetour, ArrayList <Joueur> joueurs, Plateau plateau) {
		this.nbRetour = nbRetour;
		this.joueurs = new ArrayList <Joueur> ();
		this.plateau = plateau;
	}
	
	public Joueur init () {
		if (this.gagnant != null) {
			return this.gagnant;
		}
		else {
			tour_suivant();
			return init();
		}
	}
	
	public void tour_suivant() {
		if (this.joueurs.size()<=actuel) {
			actuel = 0;
		}
		action(joueurs.get(actuel));
		actuel++;
	}
	
	public void action(Joueur j) {
		ArrayList <Deplacement> d = this.plateau.test_possible(j);
		if (d.isEmpty()) {
			// a completer
			tour_suivant();
		}
		else {
			choix_action(d);
		}
	}
	
	public void choix_action(ArrayList <Deplacement> d){
		
	}
}
