
public class Deplacement {
	private int x1;
	private int x2;
	private int y1;
	private int y2;
	private int z1;
	private int z2;
	private boolean block;
	
	public Deplacement(int x1, int x2, int y1, int y2, int z1, int z2, boolean block) {
		this.x1=x1;
		this.x2=x2;
		this.y1=y1;
		this.y2=y2;
		this.z1=z1;
		this.z2=z2;
		this.block = block;
	}
	
	public Deplacement (Joueur j, int x, int y, int z) {
		x2 =x;
		y2 =y;
		z2 =z;
	}
	
	public Deplacement inverse() {
		return new Deplacement (x2,x1,y2,y1,z2,z1,block);
	}
}
